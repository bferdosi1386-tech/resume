const startbtn= document.getElementById("startbtn");
const paperbtn= document.getElementById("paperbtn");
const rockbtn= document.getElementById("rockbtn");
const scissorsbtn= document.getElementById("scissorsbtn");
const scoreElement= document.getElementById("score");
const resultElement= document.getElementById("result");

let score=parseInt(scoreElement.innerText);

function startgame(){
    paperbtn.disabled=false;
     rockbtn.disabled=false;
      scissorsbtn.disabled=false;
      resultElement.innerText= "GAME STARTED! MAKE YOUR CHOICES :)";
      document.getElementById("startbtn").disabled= true;
      
};
paperbtn.addEventListener("click",()=> play("paper"));
rockbtn.addEventListener("click",()=> play("rock"));
scissorsbtn.addEventListener("click",()=> play("scissors"));

function play(playerchoices){
    const choices=["rock","paper","scissors"];
    const computerchoices=choices[Math.floor(Math.random()*3)]
    let result="";
    if(playerchoices===computerchoices){
result="It is a tie";
    }else if(
        (playerchoices==="rock"&& computerchoices==="scissors") ||
         (playerchoices==="scissors"&& computerchoices==="paper") ||
          (playerchoices==="paper"&& computerchoices==="rock")
    ){
        result="You Win :)"
        score +=1
    }else{
            result="You lose :("
        score -=1
    }
    scoreElement.innerText= score;
    resultElement.innerText=`You chose ${playerchoices}, Computer chose ${computerchoices} So ${result}`;
}