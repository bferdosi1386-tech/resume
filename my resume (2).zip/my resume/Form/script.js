const form= document.getElementById("Contactform");
const Name= document.getElementById("Name");
const user=document.getElementById("user");
const email=document.getElementById("email");
const pass=document.getElementById("pass");
const Conpass=document.getElementById("Conpass");
let errortext="";
document.addEventListener("DOMContentLoaded", validation);

function validation() {
    if (Name.value.trim === "") {
  errortext = "Name";
} else if (user.value.trim === "") {
  errortext = "user";
}
switch (errortext) {
  case "name":
    document.getElementById("Name").innerHTML = "**لطفا نام را تکمیل کنید";
    break;

  case "user":
    document.getElementById("User").innerHTML = "**لطفا نام کاربری خود را وارد کنید";
    break;

}
}
