const startbtn = document.getElementById("startbtn");
const paperbtn = document.getElementById("paperbtn");
const scissorsbtn = document.getElementById("scissorsbtn");
const rockbtn = document.getElementById("rockbtn");
const scoreElement = document.getElementById("score");
const messageElement = document.getElementById("message");

let score = parseInt(scoreElement.innerText); 

function startGame() {
    paperbtn.disabled = false;
    scissorsbtn.disabled = false;
    rockbtn.disabled = false;

    messageElement.innerText = "Game started! Make your choices.";
    document.getElementById("startbtn").disabled = true;
};

rockbtn.addEventListener("click", () => play("rock"));
paperbtn.addEventListener("click", () => play("paper"));
scissorsbtn.addEventListener("click", () => play("scissors"));

function play(playerchoice) {
    const choices = ["rock", "paper", "scissors"];
    const computerchoice = choices[Math.floor(Math.random() * 3)];

    let resultMessage = "";

    if (playerchoice === computerchoice) {
        resultMessage = "It's a tie!";
    } else if (
        (playerchoice === "rock" && computerchoice === "scissors") ||
        (playerchoice === "paper" && computerchoice === "rock") ||
        (playerchoice === "scissors" && computerchoice === "paper")
    ) {
        resultMessage = "You win!";
        score += 1;
    } else {
        resultMessage = "You lose!";
        score -= 1;
    }

    scoreElement.innerText = score;
    messageElement.innerText = `You chose ${playerchoice}, computer chose ${computerchoice}. ${resultMessage}`;
}


